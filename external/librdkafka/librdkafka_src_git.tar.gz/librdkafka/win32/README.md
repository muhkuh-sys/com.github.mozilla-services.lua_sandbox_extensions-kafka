# Build guide for Windows

* build.bat - Build for all combos of: Win32,x64,Release,Debug using the current msbuild toolset
* build-package.bat - Build NuGet packages (wrapper for package-nuget.ps1)
* package-nuget.ps1 - Build NuGet packages (using build.bat artifacts)
* push-package.bat - Push NuGet packages to NuGet (edit script for version)
